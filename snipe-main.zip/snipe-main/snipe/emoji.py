# アラーム絵文字（絶対）
ALARM_CLOCK = "\U000023F0"
# タイマー絵文字（相対）
TIMER_CLOCK = "\U000023F2"
